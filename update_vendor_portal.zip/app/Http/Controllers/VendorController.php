<?php

namespace App\Http\Controllers;

use App\Models\History;
use App\Models\PurchaseRequest;
use App\Models\ServiceRequest;
use App\Models\Rfq;
use App\Models\SelectionItem;
use App\Models\Vendor;
use App\Models\VendorQuotation;
use App\Models\VendorSelection;
use App\Models\QuotationDetail;
use App\Models\QuotationSummary;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class VendorController extends Controller
{
    // ─────────────────────────────────────────────
    // Shared data builder (used by index + select)
    // ─────────────────────────────────────────────
    private function buildViewData(): array
    {
        $user = auth()->user();
        $validStatuses = ['vendor_search', 'vendor_selection'];

        $prs = PurchaseRequest::with(['items', 'rfqs.quotations.details', 'rfqs.vendorSelections.selectionItems'])
            ->whereIn('status', $validStatuses)
            ->when($user->role !== 'purchasing', fn($q) => $q->where('user_id', $user->id))
            ->latest()
            ->get()
            ->map(function ($pr) {
                $pr->setAttribute('type', 'goods');
                $pr->setAttribute('display_doc', $pr->document_number);
                $pr->setAttribute('display_title', $pr->title);
                $pr->setAttribute('document_number', $pr->document_number);
                $pr->setAttribute('title', $pr->title);
                return $pr;
            });

        $srs = ServiceRequest::with(['jobs.items', 'rfqs.quotations.details', 'rfqs.vendorSelections.selectionItems'])
            ->whereIn('status', $validStatuses)
            ->when($user->role !== 'purchasing', fn($q) => $q->where('user_id', $user->id))
            ->latest()
            ->get()
            ->map(function ($sr) {
                $docNum = $sr->document_number
                    ?? ('SR-' . ($sr->created_at ?? now())->format('Y') . '-' . str_pad($sr->id, 4, '0', STR_PAD_LEFT));
                $sr->setAttribute('type', 'service');
                $sr->setAttribute('display_doc', $docNum);
                $sr->setAttribute('display_title', $sr->service_name);
                $sr->setAttribute('document_number', $docNum);
                $sr->setAttribute('title', $sr->service_name);
                return $sr;
            });

        return [
            'prs'     => $prs->concat($srs),
            'vendors' => Vendor::where('status', 'active')->get(),
        ];
    }

    // ─────────────────────────────────────────────
    // GET /vendor-selection[?key=type_id]
    // ─────────────────────────────────────────────
    public function index(Request $request)
    {
        // ?key=goods_1 or ?key=service_1 — passed from modal "Select Vendor" button
        $selectedKey = $request->query('key', '');

        return view('vendors.index', array_merge(
            $this->buildViewData(),
            ['selectedKey' => $selectedKey]
        ));
    }

    // ─────────────────────────────────────────────
    // GET /vendor/select/{rfq}  — construct key and redirect
    // ─────────────────────────────────────────────
    public function select(Rfq $rfq)
    {
        if ($rfq->purchase_request_id) {
            $key = 'goods_' . $rfq->purchase_request_id;
        } elseif ($rfq->service_request_id) {
            $key = 'service_' . $rfq->service_request_id;
        } else {
            $key = '';
        }

        return redirect()->route('vendors.list', $key ? ['key' => $key] : []);
    }

    // ─────────────────────────────────────────────
    // POST /vendor-selection/store
    // ─────────────────────────────────────────────
    public function storeSelection(Request $request)
    {
        $request->validate([
            'purchase_request_id'      => ['required'],
            'item_type'                => ['required', 'string'],
            'selection_notes'          => ['nullable', 'string'],
            'selections'               => ['required', 'array', 'min:1'],
            'selections.*.vendor_id'   => ['required', 'exists:vendors,id'],
            'selections.*.item_id'     => ['required'],
            'selections.*.unit_price'  => ['required', 'numeric', 'min:0'],
            'selections.*.quantity'    => ['required', 'numeric', 'min:0'],
            'selections.*.notes'       => ['nullable', 'string'],
            'selections.*.unit'        => ['nullable', 'string'],
            'selections.*.specification'=> ['nullable', 'string'],
        ]);

        $isService = ($request->item_type === 'service');

        return \Illuminate\Support\Facades\DB::transaction(function () use ($request, $isService) {
            if ($isService) {
                $pr     = ServiceRequest::findOrFail($request->purchase_request_id);
                $docNum = $pr->document_number
                    ?? ('SR-' . ($pr->created_at ?? now())->format('Y') . '-' . str_pad($pr->id, 4, '0', STR_PAD_LEFT));
            } else {
                $pr     = PurchaseRequest::findOrFail($request->purchase_request_id);
                $docNum = $pr->document_number;
            }

            $rfq = $pr->rfqs()->first();
            if (!$rfq) {
                $todayCount = Rfq::whereDate('created_at', today())->count() + 1;
                $rfq = Rfq::create([
                    'purchase_request_id' => $isService ? null : $pr->id,
                    'service_request_id'  => $isService ? $pr->id : null,
                    'rfq_number'          => 'RFQ-' . now()->format('Y-md') . '-' . str_pad($todayCount, 3, '0', STR_PAD_LEFT),
                    'status'              => 'closed',
                    'opened_at'           => now(),
                ]);
            }

            $byVendor = collect($request->selections)->groupBy('vendor_id');

            foreach ($byVendor as $vendorId => $items) {
                $vendor = Vendor::find($vendorId);

                $quotation = \App\Models\Quotation::where('rfq_id', $rfq->id)
                    ->where('vendor_id', $vendorId)
                    ->first();

                $sel = VendorSelection::updateOrCreate(
                    ['rfq_id' => $rfq->id, 'vendor_id' => $vendorId],
                    [
                        'quotation_id'   => $quotation ? $quotation->id : null,
                        'decision_notes' => $request->selection_notes ?? '',
                        'decided_at'     => now(),
                    ]
                );

                $sel->selectionItems()->delete();

                foreach ($items as $row) {
                    $qd = QuotationDetail::whereHas('quotation', function ($q) use ($rfq, $vendorId) {
                        $q->where('rfq_id', $rfq->id)->where('vendor_id', $vendorId);
                    })->where(
                        $isService ? 'service_request_item_id' : 'purchase_request_item_id',
                        $row['item_id']
                    )->first();

                    $qsId = null;
                    if ($qd) {
                        $qs   = QuotationSummary::where('quotation_detail_id', $qd->id)->first();
                        $qsId = $qs ? $qs->id : null;
                    }

                    SelectionItem::create([
                        'vendor_selection_id'       => $sel->id,
                        'quotation_summary_id'      => $qsId,
                        'final_price_per_item'      => $row['unit_price'],
                        'final_quantity'            => $row['quantity'],
                        'notes'                     => $row['notes'] ?? 'Selected',
                        'final_unit'                => $row['unit'] ?? null,
                        'final_brand'               => $row['brand'] ?? null,
                        'final_specification'       => $row['specification'] ?? null,
                        'purchase_request_item_id'  => $isService ? null : $row['item_id'],
                        'service_request_item_id'   => $isService ? $row['item_id'] : null,
                    ]);
                }

                History::create([
                    'user_id'             => auth()->id(),
                    'vendor_id'           => $vendorId,
                    'rfq_id'              => $rfq->id,
                    'vendor_selection_id' => $sel->id,
                    'action'              => 'Vendor Selection Submitted',
                    'transaction_status'  => 'completed',
                    'notes'               => 'Vendor ' . ($vendor ? $vendor->vendor_name : 'Unknown') . ' dipilih untuk '
                                            . count($items) . ' item pada dokumen ' . $docNum,
                    'action_date'         => now(),
                ]);
            }

            $pr->update(['status' => 'completed']);

            // ── ASSET PUSH ──────────────────────────────────────────────────
            if (!$isService) {
                $pr->load('items');
                $assetItems = [];

                // Build a price map from SelectionItems just saved: keyed by purchase_request_item_id
                $priceMap = collect($request->selections)
                    ->keyBy('item_id')
                    ->map(fn($s) => $s['unit_price']);

                foreach ($pr->items as $item) {
                    if (!$item->is_asset) continue;

                    $hargaPenawaran = $priceMap->get($item->id);

                    $qty = $item->quantity > 0 ? $item->quantity : 1;

                    for ($i = 0; $i < $qty; $i++) {
                        $assetItems[] = [
                        'description'        => $item->item_name,
                        'business_area'      => $pr->business_area,
                        'tujuan'             => $item->purpose,
                        'harga_penawaran'    => $hargaPenawaran,
                        'department'         => $pr->department,
                        'requester'          => optional($pr->user)->email,
                        'lampiran_penawaran' => $pr->attachment_path,
                        ];
                    }
                }

                if (!empty($assetItems)) {
                    try {
                        $apiUrl = 'http://10.22.5.50:8287/public/api/receive_asset.php'; 
                        Http::timeout(10)->post($apiUrl, [
                            'api_key' => 'DICT_PURCH_SECRET_2026',
                            'assets'  => $assetItems,
                        ]);
                    } catch (\Exception $e) {
                        Log::warning('Asset push to Accounting failed: ' . $e->getMessage());
                    }
                }
            }
            // ────────────────────────────────────────────────────────────────

            $userId = $pr->user_id ?? null;
            $userCreator = $userId ? \App\Models\User::find($userId) : null;
            $purchasingUsers = \App\Models\User::where('role', 'purchasing')->get();

            dispatch(function () use ($pr, $userCreator, $purchasingUsers, $isService) {
                try {
                    $notif = new \App\Notifications\VendorSelectedNotification($pr, $isService ? 'service' : 'goods');

                    // 1. Notifikasi database & email ke Pemohon
                    if ($userCreator) {
                        $userCreator->notify($notif);
                    }

                    // 2. Notifikasi database & email ke Seluruh Tim Purchasing
                    if ($purchasingUsers->count() > 0) {
                        \Illuminate\Support\Facades\Notification::send($purchasingUsers, $notif);
                    }

                    // 3. Kirim ke email sistem purchasing jika ada
                    $companyEmail = config('mail.from.address') ?: env('MAIL_FROM_ADDRESS');
                    if ($companyEmail && !in_array($companyEmail, $purchasingUsers->pluck('email')->toArray())) {
                        \Illuminate\Support\Facades\Notification::route('mail', $companyEmail)->notify($notif);
                    }
                } catch (\Throwable $e) {
                    \Log::error('Error sending vendor selected notifications: ' . $e->getMessage());
                }
            })->afterResponse();

            return response()->json([
                'success'   => true,
                'message'   => 'Vendor selection submitted for ' . $docNum,
                'pr_number' => $docNum,
                'notes'     => $request->selection_notes ?? '—',
            ]);
        });
    }

    public function updateMaster(Request $request, $id)
    {
        $request->validate([
            'vendor_name' => 'required|string|max:255',
            'email' => 'nullable|email|max:255',
            'department' => 'nullable|string|max:255',
        ]);

        $vendor = Vendor::findOrFail($id);
        $vendor->update([
            'vendor_name' => $request->vendor_name,
            'email' => $request->email,
            'department' => $request->department,
        ]);

        return back()->with('success', 'Vendor information updated successfully.');
    }

    public function exportQuotations(Request $request)
    {
        $id = $request->query('id');
        $type = $request->query('type', 'goods');

        $doc = $type === 'service' ? ServiceRequest::findOrFail($id) : PurchaseRequest::findOrFail($id);
        
        // 1. Get all items in the request
        if ($type === 'service') {
            $items = collect();
            foreach ($doc->jobs as $job) {
                $items = $items->merge($job->items);
            }
        } else {
            $items = $doc->items;
        }

        // 2. Get all participating vendors and their quotations
        $rfqs = Rfq::with('quotations.vendor', 'quotations.details')->where($type === 'service' ? 'service_request_id' : 'purchase_request_id', $id)->get();
        $participatingVendors = [];
        $vendorQuotations = []; 
        
        foreach ($rfqs as $rfq) {
            foreach ($rfq->quotations as $quotation) {
                $v = $quotation->vendor;
                $vName = $v->vendor_name ?? $v->name ?? 'Unknown Vendor';
                $participatingVendors[$quotation->id] = $vName;
                $vendorQuotations[$quotation->id] = $quotation;
            }
        }

        // 3. Build headers
        $headerTop = ['<b>NO.</b>', '<b>ITEM ID</b>', '<b>ITEM NAME</b>', '<b>QTY</b>', '<b>UNIT</b>', '<b>NOTES</b>'];
        $headerBottom = ['', '', '', '', '', ''];
        
        foreach ($participatingVendors as $vName) {
            $headerTop[] = '<b>' . $vName . '</b>';
            $headerTop[] = '';
            $headerTop[] = '';
            $headerTop[] = '';
            $headerTop[] = '';
            
            $headerBottom[] = '<b>QTY</b>';
            $headerBottom[] = '<b>UNIT</b>';
            $headerBottom[] = '<b>PRICE</b>';
            $headerBottom[] = '<b>TOTAL PRICE</b>';
            $headerBottom[] = '<b>NOTES</b>';
        }
        $data = [$headerTop, $headerBottom];

        // 4. Build rows per item
        $no = 1;
        $vendorTotals = array_fill_keys(array_keys($participatingVendors), 0);

        foreach ($items as $item) {
            $fullName = $item->full_name ?? ($item->item_name . '_' . ($item->specification ?: 'nsp') . '_' . ($item->brand ?: 'nbr'));
            $fullName = \Illuminate\Support\Str::limit($fullName, 40, '');
            $row = [
                $no++,
                $item->item_id ?? '-',
                $fullName,
                $item->quantity ?? '-',
                $item->unit ?? '-',
                $item->item_notes ?? $item->admin_notes ?? '-'
            ];

            $vendorCells = [];

            foreach ($vendorQuotations as $qId => $quotation) {
                $detail = $quotation->details->first(function($d) use ($item, $type) {
                    if ($type === 'service') {
                        return $d->service_request_item_id == $item->id;
                    }
                    return $d->purchase_request_item_id == $item->id;
                });

                if ($detail) {
                    $vendorDiffSpec = (!empty($detail->offered_brand) || !empty($detail->offered_specification));

                    $qQty = $detail->offered_quantity ?? $item->quantity;
                    $qUnit = $detail->offered_unit ?? $item->unit;
                    $qPrice = $detail->offered_price_per_item ?? 0;
                    $qTotal = $qQty * $qPrice;
                    
                    $qtyFmt = ($qQty != $item->quantity) ? '<style bgcolor="#fcd34d">' . $qQty . '</style>' : $qQty;
                    $unitFmt = (strtolower(trim($qUnit)) != strtolower(trim($item->unit))) ? '<style bgcolor="#fcd34d">' . $qUnit . '</style>' : $qUnit;

                    $vendorCells[] = [
                        'diff' => $vendorDiffSpec,
                        'qty' => $qtyFmt,
                        'unit' => $unitFmt,
                        'price' => $qPrice,
                        'total' => $qTotal,
                        'notes' => $detail->item_notes ?? '-',
                    ];
                    
                    $vendorTotals[$qId] += $qTotal;
                } else {
                    $vendorCells[] = [
                        'diff' => false,
                        'qty' => '-',
                        'unit' => '-',
                        'price' => '-',
                        'total' => '-',
                        'notes' => '-',
                    ];
                }
            }

            // Append each vendor's cells to the row. Highlight only their specific cells if they offered a different spec.
            foreach ($vendorCells as $vCell) {
                if ($vCell['diff']) {
                    $row[] = '<style bgcolor="#fef08a">' . strip_tags($vCell['qty']) . '</style>';
                    $row[] = '<style bgcolor="#fef08a">' . strip_tags($vCell['unit']) . '</style>';
                    $row[] = '<style bgcolor="#fef08a">' . $vCell['price'] . '</style>';
                    $row[] = '<style bgcolor="#fef08a">' . $vCell['total'] . '</style>';
                    $row[] = '<style bgcolor="#fef08a">' . $vCell['notes'] . '</style>';
                } else {
                    $row[] = $vCell['qty'];
                    $row[] = $vCell['unit'];
                    $row[] = $vCell['price'];
                    $row[] = $vCell['total'];
                    $row[] = $vCell['notes'];
                }
            }

            $data[] = $row;
        }
        
        // 5. Build Grand Total row
        $totalRow = ['', '', '', '', '', '<b>GRAND TOTAL</b>'];
        foreach ($participatingVendors as $qId => $vName) {
            $totalRow[] = '';
            $totalRow[] = '';
            $totalRow[] = '';
            $totalRow[] = '';
            $totalRow[] = '<b>' . $vendorTotals[$qId] . '</b>';
        }
        $data[] = $totalRow;

        $xlsFileName = "quotations_{$doc->document_number}_" . date('Ymd_His') . '.xlsx';
        $xlsx = \Shuchkin\SimpleXLSXGen::fromArray($data);

        return response((string) $xlsx, 200, [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'Content-Disposition' => 'attachment; filename="' . $xlsFileName . '"',
            'Cache-Control' => 'max-age=0',
        ]);
    }

    public function exportSummaryPo(Request $request)
    {
        $id = $request->input('purchase_request_id');
        $type = $request->input('item_type', 'goods');
        $selectionsRaw = json_decode($request->input('selections_json', '[]'), true) ?: [];

        $doc = $type === 'service' ? ServiceRequest::with('jobs.items')->findOrFail($id) : PurchaseRequest::with('items')->findOrFail($id);
        $vendors = Vendor::pluck('vendor_name', 'id')->toArray();

        $itemMap = [];
        $jobScopeMap = [];
        if ($type === 'service') {
            foreach ($doc->jobs as $job) {
                foreach ($job->items as $it) {
                    $itemMap[$it->id] = $it;
                    $jobScopeMap[$it->id] = $job->job_description ?? $job->description ?? '-';
                }
            }
        } else {
            foreach ($doc->items as $it) {
                $itemMap[$it->id] = $it;
            }
        }

        $docTitle = $type === 'service' ? ($doc->service_name ?? $doc->title ?? '-') : ($doc->title ?? '-');

        $data = [
            ['<b>SUMMARY PO UNTUK ' . $doc->document_number . '</b>'],
            ['<b>Deskripsi:</b>', $docTitle],
            ['<b>Tanggal Export:</b>', now()->format('d M Y H:i')],
            [],
            ['<b>SELECTED ITEMS</b>'],
        ];

        if ($type === 'service') {
            $data[] = ['<b>NO.</b>', '<b>SCOPE PEKERJAAN</b>', '<b>ITEM NAME</b>', '<b>VENDOR</b>', '<b>BUY QTY</b>', '<b>UNIT</b>', '<b>PRICE (RP)</b>', '<b>SUBTOTAL (RP)</b>'];
        } else {
            $data[] = ['<b>NO.</b>', '<b>ITEM ID</b>', '<b>ITEM NAME</b>', '<b>VENDOR</b>', '<b>BUY QTY</b>', '<b>UNIT</b>', '<b>PRICE (RP)</b>', '<b>SUBTOTAL (RP)</b>'];
        }

        $no = 1;
        $grandTotal = 0;
        $perVendor = [];

        foreach ($selectionsRaw as $sel) {
            $vId = $sel['vendor_id'] ?? null;
            $vName = $vendors[$vId] ?? ($sel['vendor_name'] ?? 'Unknown Vendor');
            $itId = $sel['item_id'] ?? null;
            $origItem = $itemMap[$itId] ?? null;

            $itemName = $sel['item_name'] ?? ($origItem->item_name ?? $origItem->name ?? '-');
            $qty = (float) ($sel['quantity'] ?? 0);
            $unit = $sel['unit'] ?? ($origItem->unit ?? '-');
            $price = (float) ($sel['unit_price'] ?? 0);
            $subtotal = $qty * $price;
            $grandTotal += $subtotal;

            if ($type === 'service') {
                $scope = $jobScopeMap[$itId] ?? '-';
                $data[] = [
                    $no++,
                    $scope,
                    $itemName,
                    $vName,
                    $qty,
                    $unit,
                    $price,
                    $subtotal,
                ];
            } else {
                $itemCode = $origItem->item_id ?? '-';
                $data[] = [
                    $no++,
                    $itemCode,
                    $itemName,
                    $vName,
                    $qty,
                    $unit,
                    $price,
                    $subtotal,
                ];
            }

            if (!isset($perVendor[$vId])) {
                $perVendor[$vId] = [
                    'vendor_name' => $vName,
                    'total' => 0,
                    'items' => [],
                ];
            }
            $perVendor[$vId]['total'] += $subtotal;
            $perVendor[$vId]['items'][] = [
                'scope' => $type === 'service' ? ($jobScopeMap[$itId] ?? '-') : null,
                'item_name' => $itemName,
                'qty' => $qty,
                'unit' => $unit,
                'price' => $price,
                'subtotal' => $subtotal,
            ];
        }

        $data[] = ['', '', '', '', '', '', '<b>GRAND TOTAL</b>', '<b>' . $grandTotal . '</b>'];
        $data[] = [];
        $data[] = ['<b>TOTAL PER VENDOR</b>'];
        $data[] = ['<b>VENDOR</b>', '<b>ITEM / PEKERJAAN</b>', '<b>BUY QTY</b>', '<b>UNIT</b>', '<b>PRICE (RP)</b>', '<b>SUBTOTAL (RP)</b>'];

        foreach ($perVendor as $vGroup) {
            foreach ($vGroup['items'] as $idx => $vIt) {
                $label = $vIt['scope'] ? ('[' . $vIt['scope'] . '] ' . $vIt['item_name']) : $vIt['item_name'];
                $data[] = [
                    $idx === 0 ? '<b>' . $vGroup['vendor_name'] . '</b>' : '',
                    $label,
                    $vIt['qty'],
                    $vIt['unit'],
                    $vIt['price'],
                    $vIt['subtotal'],
                ];
            }
            $data[] = [
                '',
                '',
                '',
                '',
                '<b>Total ' . $vGroup['vendor_name'] . '</b>',
                '<b>' . $vGroup['total'] . '</b>',
            ];
            $data[] = [];
        }

        $xlsFileName = "summary_po_{$doc->document_number}_" . date('Ymd_His') . '.xlsx';
        $xlsx = \Shuchkin\SimpleXLSXGen::fromArray($data);

        return response((string) $xlsx, 200, [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'Content-Disposition' => 'attachment; filename="' . $xlsFileName . '"',
            'Cache-Control' => 'max-age=0',
        ]);
    }

    // ─────────────────────────────────────────────
    // GET /api/vendors
    // ─────────────────────────────────────────────
    public function apiList()
    {
        return response()->json(Vendor::all());
    }
}