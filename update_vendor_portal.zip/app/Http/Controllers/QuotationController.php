<?php

namespace App\Http\Controllers;

use App\Models\History;
use App\Models\Quotation;
use App\Models\QuotationDetail;
use App\Models\QuotationSummary;
use App\Models\Rfq;
use App\Models\SelectionItem;
use App\Models\PurchaseRequest;
use App\Models\VendorSelection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class QuotationController extends Controller
{
    public function create(Rfq $rfq)
    {
        $rfq->load([
            'purchaseRequest.items',
            'serviceRequest.jobs.items',
            'vendor'
        ]);

        return view('quotations.create', compact('rfq'));
    }

    public function store(Request $request, Rfq $rfq)
    {
        $data = $request->validate([
            'vendor_id' => ['nullable', 'exists:vendors,id'],
            'new_vendor_name' => ['nullable', 'string', 'max:255'],
            'new_vendor_location' => ['nullable', 'string', 'max:255'],
            'new_vendor_email' => ['nullable', 'email', 'max:255'],
            'items' => ['required', 'array'],
            'items.*.item_id' => ['required'], // PR item or SR item ID
            'items.*.price' => ['nullable', 'numeric', 'min:0'],
            'items.*.quantity' => ['nullable', 'numeric', 'min:0'],
            'items.*.unit' => ['nullable', 'string'],
            'items.*.specification' => ['nullable', 'string'],
            'items.*.notes' => ['nullable', 'string'],
            'note' => ['nullable', 'string'],
        ]);

        $quotedItems = collect($data['items'])->filter(function ($it) {
            return isset($it['price']) && $it['price'] !== '' && $it['price'] !== null && (float) $it['price'] > 0;
        });

        if ($quotedItems->isEmpty()) {
            return back()->withErrors(['items' => 'Mohon isi harga penawaran minimal pada 1 item.'])->withInput();
        }

        // Resolve vendor
        $vendorId = $data['vendor_id'];
        if ($vendorId && !empty($data['new_vendor_name'])) {
            $existingV = \App\Models\Vendor::find($vendorId);
            if ($existingV && strtolower(trim($existingV->vendor_name)) !== strtolower(trim($data['new_vendor_name']))) {
                $vendorId = null;
            }
        }
        if (!$vendorId && !empty($data['new_vendor_name'])) {
            $existingByName = \App\Models\Vendor::whereRaw('LOWER(TRIM(vendor_name)) = ?', [strtolower(trim($data['new_vendor_name']))])->first();
            if ($existingByName) {
                $vendorId = $existingByName->id;
            } else {
                $vendor = \App\Models\Vendor::create([
                    'vendor_name' => trim($data['new_vendor_name']),
                    'location' => $data['new_vendor_location'] ?: '-',
                    'email' => $data['new_vendor_email'],
                    'status' => 'active',
                ]);
                $vendorId = $vendor->id;
            }
        }

        if (!$vendorId) {
            return back()->withErrors(['vendor_id' => 'Please select or create a vendor.'])->withInput();
        }

        // Update RFQ vendor if not set
        if (!$rfq->vendor_id) {
            $rfq->vendor_id = $vendorId;
            $rfq->save();
        }

        $totalPrice = $quotedItems->sum(fn($it) => (float) $it['price'] * (float) ($it['quantity'] ?? 1));

        // Create or Update Quotation for this RFQ + Vendor
        $quotation = Quotation::where('rfq_id', $rfq->id)->where('vendor_id', $vendorId)->first();
        if ($quotation) {
            $quotation->update([
                'total_price' => $totalPrice,
                'note' => $data['note'] ?? null,
                'status' => 'submitted',
            ]);
            QuotationDetail::where('quotation_id', $quotation->id)->delete();
        } else {
            $quotation = Quotation::create([
                'rfq_id' => $rfq->id,
                'vendor_id' => $vendorId,
                'total_price' => $totalPrice,
                'note' => $data['note'] ?? null,
                'status' => 'submitted',
            ]);
        }

        // Create details for quoted items
        $isService = (bool) $rfq->service_request_id;
        foreach ($quotedItems as $it) {
            QuotationDetail::create([
                'quotation_id' => $quotation->id,
                'purchase_request_item_id' => $isService ? null : $it['item_id'],
                'service_request_item_id' => $isService ? $it['item_id'] : null,
                'offered_price_per_item' => $it['price'],
                'offered_quantity' => $it['quantity'] ?? 1,
                'offered_unit' => $it['unit'] ?? null,
                'offered_brand' => $it['brand'] ?? null,
                'offered_specification' => $it['specification'] ?? null,
                'item_notes' => $it['notes'] ?? null,
            ]);
        }

        // Transition PR/SR status to vendor_selection if it is currently vendor_search
        $pr = $isService ? $rfq->serviceRequest : $rfq->purchaseRequest;
        if ($pr && $pr->status === 'vendor_search') {
            $pr->status = 'vendor_selection';
            $pr->save();
        }

        History::create([
            'user_id' => auth()->id(),
            'vendor_id' => $vendorId,
            'rfq_id' => $rfq->id,
            'action' => 'Manual Quotation Added',
            'transaction_status' => 'completed',
            'notes' => 'Quotation added manually by Admin',
            'action_date' => now(),
        ]);

                // Mulai: Kirim Notifikasi & Email
        $vendorModel = \App\Models\Vendor::find($vendorId);
        if ($vendorModel) {
            $purchasingUsers = \App\Models\User::where('role', 'purchasing')->get();
            
            dispatch(function () use ($pr, $rfq, $vendorModel, $quotation, $purchasingUsers) {
                try {
                    // 1. Kirim ke User Pembuat PR/SR (Peminta Barang)
                    if ($pr && $pr->user_id) {
                        $userCreator = \App\Models\User::find($pr->user_id);
                        if ($userCreator) {
                            $userCreator->notify(new \App\Notifications\VendorQuotationSubmitted($rfq, $vendorModel));
                        }
                    }
                    
                    // 2. Kirim ke Seluruh Tim Purchasing (Database Notification)
                    if ($purchasingUsers->count() > 0) {
                        \Illuminate\Support\Facades\Notification::send($purchasingUsers, new \App\Notifications\VendorQuotationSubmitted($rfq, $vendorModel));
                    }

                    // 3. Kirim Email Quotation ke Seluruh Tim Purchasing
                    if ($purchasingUsers->count() > 0 && $quotation) {
                        \Illuminate\Support\Facades\Notification::send($purchasingUsers, new \App\Notifications\CompanyQuotationSubmitted($rfq, $vendorModel, $quotation));
                    }

                    // 4. Kirim Email ke Alamat Sistem jika dikonfigurasi
                    $companyEmail = config('mail.from.address') ?: env('MAIL_FROM_ADDRESS');
                    if ($companyEmail && $quotation && !in_array($companyEmail, $purchasingUsers->pluck('email')->toArray())) {
                        \Illuminate\Support\Facades\Notification::route('mail', $companyEmail)->notify(new \App\Notifications\CompanyQuotationSubmitted($rfq, $vendorModel, $quotation));
                    }
                } catch (\Throwable $e) {
                    \Log::error('Error sending manual quotation notification: ' . $e->getMessage());
                }
            })->afterResponse();
        }
        // Selesai: Kirim Notifikasi & Email

        return redirect()->route('dashboard')->with('success', 'Manual quotation saved successfully.');
    }

    public function edit($id)
    {
        $quotation = Quotation::with([
            'rfq.purchaseRequest.items',
            'rfq.serviceRequest.jobs.items',
            'details'
        ])->findOrFail($id);
        
        $rfq = $quotation->rfq;
        return view('quotations.edit', compact('quotation', 'rfq'));
    }

    public function update(Request $request, $id)
    {
        $quotation = Quotation::findOrFail($id);
        $rfq = $quotation->rfq;

        $data = $request->validate([
            'items' => ['required', 'array'],
            'items.*.detail_id' => ['required', 'exists:quotation_details,id'],
            'items.*.price' => ['required', 'numeric', 'min:0'],
            'items.*.quantity' => ['required', 'numeric', 'min:0'],
            'items.*.unit' => ['nullable', 'string'],
            'items.*.specification' => ['nullable', 'string'],
            'items.*.notes' => ['nullable', 'string'],
            'note' => ['nullable', 'string'],
        ]);

        $total = 0;
        foreach ($data['items'] as $it) {
            $detail = QuotationDetail::findOrFail($it['detail_id']);
            $detail->update([
                'offered_price_per_item' => $it['price'],
                'offered_quantity' => $it['quantity'],
                'offered_unit' => $it['unit'] ?? null,
                'offered_brand' => $it['brand'] ?? null,
                'offered_specification' => $it['specification'] ?? null,
                'item_notes' => $it['notes'] ?? null,
            ]);
            $total += ($it['price'] * $it['quantity']);
        }

        $quotation->update([
            'total_price' => $total,
            'note' => $data['note'] ?? null,
        ]);

        History::create([
            'user_id' => auth()->id(),
            'vendor_id' => $quotation->vendor_id,
            'rfq_id' => $rfq->id,
            'action' => 'Quotation Updated',
            'transaction_status' => 'completed',
            'notes' => 'Quotation updated manually by Admin',
            'action_date' => now(),
        ]);

        return redirect()->route('dashboard')->with('success', 'Quotation updated successfully.');
    }

    public function status(Rfq $rfq)
    {
        $rfq->load(['purchaseRequest', 'vendor', 'vendorQuotations.vendor', 'quotationPeriods', 'quotation.details']);

        return view('quotations.status', compact('rfq'));
    }

    public function updateStatus(Request $request, Rfq $rfq)
    {
        $data = $request->validate([
            'status' => ['required', 'in:open,closed'],
            'closed_at' => ['nullable', 'date'],
            'note' => ['nullable', 'string'],
        ]);

        $rfq->status = $data['status'];
        $rfq->closed_at = $data['status'] === 'closed' ? ($data['closed_at'] ?? now()) : null;
        $rfq->note = $data['note'] ?? $rfq->note;
        $rfq->save();

        if ($data['status'] === 'closed') {
            $period = $rfq->quotationPeriods()->latest('round')->first();
            if ($period) {
                $period->status = 'closed';
                $period->save();
            }
        }

        History::create([
            'user_id' => auth()->id(),
            'vendor_id' => $rfq->vendor_id,
            'rfq_id' => $rfq->id,
            'vendor_selection_id' => null,
            'action' => 'RFQ Status Updated',
            'transaction_status' => 'completed',
            'notes' => 'RFQ status set to ' . $rfq->status,
            'action_date' => now(),
        ]);

        return redirect()->route('quotations.final', $rfq)->with('success', 'Status RFQ berhasil diperbarui.');
    }

    public function final(Rfq $rfq)
    {
        $quotation = $rfq->quotation;
        $isService = (bool) $rfq->service_request_id;
        $items = $isService ? $rfq->serviceRequest->jobs->flatMap->items : $rfq->purchaseRequest->items;
        $details = $quotation ? $quotation->details->keyBy($isService ? 'service_request_item_id' : 'purchase_request_item_id') : collect();

        return view('quotations.final', compact('rfq', 'quotation', 'items', 'details'));
    }

    public function storeFinal(Request $request, Rfq $rfq)
    {
        $isService = (bool) $rfq->service_request_id;
        $itemTable = $isService ? 'service_request_items' : 'purchase_request_items';
        $itemColumn = $isService ? 'service_request_item_id' : 'purchase_request_item_id';

        $data = $request->validate([
            'total_price' => ['required', 'numeric', 'min:0'],
            'note' => ['nullable', 'string'],
            'items' => ['required', 'array', 'min:1'],
            "items.*.{$itemColumn}" => ['required', "exists:{$itemTable},id"],
            'items.*.offered_price_per_item' => ['required', 'numeric', 'min:0'],
            'items.*.offered_quantity' => ['required', 'numeric', 'min:0'],
        ]);

        $quotation = Quotation::updateOrCreate([
            'rfq_id' => $rfq->id,
        ], [
            'vendor_id' => $rfq->vendor_id,
            'total_price' => $data['total_price'],
            'note' => $data['note'] ?? null,
            'status' => 'finalized',
        ]);

        QuotationDetail::where('quotation_id', $quotation->id)->delete();
        QuotationSummary::where('rfq_id', $rfq->id)->delete();

        foreach ($data['items'] as $itemData) {
            $detail = QuotationDetail::create([
                'quotation_id' => $quotation->id,
                'purchase_request_item_id' => $isService ? null : $itemData['purchase_request_item_id'],
                'service_request_item_id' => $isService ? $itemData['service_request_item_id'] : null,
                'offered_price_per_item' => $itemData['offered_price_per_item'],
                'offered_quantity' => $itemData['offered_quantity'],
            ]);

            QuotationSummary::create([
                'rfq_id' => $rfq->id,
                'quotation_detail_id' => $detail->id,
                'is_sent_to_user' => true,
                'sent_to_user_at' => now(),
            ]);
        }

        $selection = VendorSelection::updateOrCreate([
            'rfq_id' => $rfq->id,
        ], [
            'vendor_id' => $rfq->vendor_id,
            'quotation_id' => $quotation->id,
            'decision_notes' => 'Final quotation selected and approved.',
            'decided_at' => now(),
        ]);

        SelectionItem::where('vendor_selection_id', $selection->id)->delete();

        $summaryIds = QuotationSummary::where('rfq_id', $rfq->id)
            ->pluck('id', 'quotation_detail_id')
            ->toArray();

        foreach ($quotation->details as $detail) {
            SelectionItem::create([
                'vendor_selection_id' => $selection->id,
                'quotation_summary_id' => $summaryIds[$detail->id] ?? null,
                'final_price_per_item' => $detail->offered_price_per_item,
                'final_quantity' => $detail->offered_quantity,
                'notes' => 'Item included in final vendor selection.',
            ]);
        }

        $rfq->status = 'closed';
        $rfq->save();
        
        if ($isService) {
            $rfq->serviceRequest->update(['status' => 'completed']);
        } else {
            $pr = $rfq->purchaseRequest;
            $pr->update(['status' => 'completed']);

            // ── ASSET PUSH ──────────────────────────────────────────────────
            // Load price data: keyed by purchase_request_item_id
            $prices = $quotation->details
                ->whereNotNull('purchase_request_item_id')
                ->keyBy('purchase_request_item_id');

            $pr->load('items');
            $assetItems = [];

            foreach ($pr->items as $item) {
                if (!$item->is_asset) continue;

                $priceDetail = $prices->get($item->id);
                $hargaPenawaran = $priceDetail ? $priceDetail->offered_price_per_item : null;

                $qty = $item->quantity > 0 ? $item->quantity : 1;

                for ($i = 0; $i < $qty; $i++) {
                    $assetItems[] = [
                    'description'      => $item->item_name,
                    'business_area'    => $pr->business_area,
                    'tujuan'           => $item->purpose,
                    'harga_penawaran'  => $hargaPenawaran,
                    'department'       => $pr->department,
                    'requester'        => optional($pr->user)->email,
                    'lampiran_penawaran' => $pr->attachment_path,
                    ];
                }
            }

            if (!empty($assetItems)) {
                try {
                    $apiUrl = 'http://10.22.5.50:8287/public/api/receive_asset.php'; 
                    Http::timeout(10)->post($apiUrl, [
                        'api_key' => 'DICT_PURCH_SECRET_2026',
                        'assets'  => $assetItems,
                    ]);
                } catch (\Exception $e) {
                    Log::warning('Asset push to Accounting failed: ' . $e->getMessage());
                }
            }
            // ────────────────────────────────────────────────────────────────
        }

        History::create([
            'user_id' => auth()->id(),
            'vendor_id' => $rfq->vendor_id,
            'rfq_id' => $rfq->id,
            'vendor_selection_id' => $selection->id,
            'action' => 'Quotation Finalized',
            'transaction_status' => 'completed',
            'notes' => 'Final quotation saved for RFQ ' . $rfq->id,
            'action_date' => now(),
        ]);

        return redirect()->route('dashboard')->with('success', 'Quotation final berhasil disimpan.');
    }

    public function generateVendorLink(Request $request, Rfq $rfq)
    {
        // 1 tautan spesifik untuk 1 RFQ (berlaku untuk beberapa vendor). Berlaku selama PR masih open.
        if (!$rfq->vendor_token) {
            $rfq->vendor_token = \Illuminate\Support\Str::random(32);
            $rfq->save();
        }

        $link = $request->getSchemeAndHttpHost() . '/vendors/quote/' . $rfq->vendor_token;
        return response()->json(['link' => $link]);
    }
}